# HerWatchlist ♡

A Streamlit + Groq AI student startup prototype for curated K-Drama, C-Drama, and Western movie recommendations.

## Features
- Branded HerWatchlist homepage
- Hera entertainment-focused AI chatbot
- Sidebar controls for language, tone, and AI creativity
- Mood-based recommendations from a starter CSV catalog
- Search and filter by content category
- Session-based personal watchlist with viewing statuses
- Basic prompt-injection resistance and API error handling

## 1. Requirements
- Python 3.10+
- A Groq API key
- Internet connection for the Groq API

## 2. Install
Open a terminal in the HerWatchlist folder:

```bash
python -m venv .venv
```

Activate the environment:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS / Linux**
```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## 3. Add your Groq API key

Recommended: copy `.streamlit/secrets.toml.example` to `.streamlit/secrets.toml`, then replace the placeholder with your key:

```toml
GROQ_API_KEY = "gsk_your_real_key"
```

Alternatively, set the `GROQ_API_KEY` environment variable. You can also paste a key into the app sidebar for the current session.

**Never commit `secrets.toml` or share your API key.** The file is included in `.gitignore`.

## 4. Run the app

```bash
streamlit run app.py
```

Streamlit will show a local URL, usually `http://localhost:8501`.

## 5. Important prototype notes
- The starter catalog is a small demonstration dataset in `data/movies.csv`. Expand it carefully and verify title metadata before presenting.
- Hera uses the catalog supplied by the app. It does not have live access to streaming availability or a verified external movie database.
- Watchlist data is stored in Streamlit session state. It is not a permanent account/database yet.
- The AI model configured in `utils/chatbot.py` is `llama-3.3-70b-versatile`. If Groq changes model availability, update `MODEL_NAME` to a model currently enabled for your Groq account.
- Prompt-injection defenses are basic safeguards, not a guarantee against every attack. Never put secrets in prompts or expose them to users.

## Suggested next improvements
1. Add SQLite for persistent watchlists.
2. Add poster images from licensed/authorized sources.
3. Add source links for catalog metadata.
4. Add user accounts only if the project has time and appropriate privacy safeguards.
