import os
import requests
import pandas as pd
import streamlit as st

from utils.chatbot import build_messages, ask_hera, get_api_key
from utils.recommendations import filter_catalog, mood_suggestions

st.set_page_config(
    page_title="HerWatchlist — Find your next favorite story",
    page_icon="♡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------- Styling ----------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap');

:root { --rose:#b45c7d; --wine:#71384f; --cream:#fffaf6; --pink:#f8eaf0; }
html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp { background: linear-gradient(180deg, #fffaf7 0%, #fff 58%, #fff8fb 100%); }
h1, h2, h3 { font-family: 'Playfair Display', serif !important; color: #71384f; }
[data-testid="stSidebar"] { background: #fbf0f4; border-right: 1px solid #f0dce5; }
[data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2 { color:#71384f; }
.hero {
    background: linear-gradient(120deg, #f7e5ed 0%, #fff4ed 100%);
    border: 1px solid #efd9e3; border-radius: 24px; padding: 30px 34px;
    margin: 4px 0 24px 0;
}
.hero-kicker { color:#9b5873; font-size:0.78rem; font-weight:700; letter-spacing:2px; text-transform:uppercase; }
.hero-title { font-family:'Playfair Display',serif; color:#71384f; font-size:2.55rem; line-height:1.12; margin:8px 0; }
.hero-copy { color:#775b68; font-size:1rem; max-width:720px; }
.pill {
    display:inline-block; padding:5px 11px; border-radius:99px; background:#f8eaf0;
    color:#854760; font-size:0.78rem; margin:4px 5px 0 0; border:1px solid #efd8e2;
}
.movie-card {
    background:white; border:1px solid #f0e2e8; border-radius:18px; padding:16px;
    min-height:220px; box-shadow:0 5px 18px rgba(113,56,79,.045);
}
.movie-emoji { font-size:2rem; background:#fbf0f4; width:54px; height:54px; display:flex;
    align-items:center; justify-content:center; border-radius:15px; margin-bottom:12px; }
.movie-title { font-family:'Playfair Display',serif; color:#71384f; font-size:1.12rem; font-weight:600; }
.movie-meta { color:#987b88; font-size:.78rem; margin:4px 0 9px 0; }
.movie-desc { color:#5f5057; font-size:.88rem; line-height:1.5; }
div.stButton > button {
    border-radius: 12px; border:1px solid #e6c7d5; color:#71384f; background:#fff8fb;
    font-weight:600;
}
div.stButton > button:hover { border-color:#b45c7d; color:#71384f; background:#f8eaf0; }
[data-testid="stChatMessage"] { border:1px solid #f1e2e8; border-radius:16px; }
.small-note { color:#8b7780; font-size:.78rem; }
</style>
""", unsafe_allow_html=True)

# ---------- Data & state ----------
@st.cache_data
def load_catalog():
    path = os.path.join("data", "movies.csv")
    return pd.read_csv(path).fillna("")

catalog = load_catalog()

for key, default in {
    "messages": [],
    "watchlist": [],
    "watch_status": {},
    "active_tab": "Discover",
}.items():
    if key not in st.session_state:
        st.session_state[key] = default

# ---------- Sidebar ----------
with st.sidebar:
    st.markdown("## ♡ HerWatchlist")
    st.caption("Your personal entertainment curator")
    st.divider()

    page = st.radio(
        "Explore HerWatchlist",
        ["Discover", "Ask Hera AI", "My Watchlist", "About"],
        label_visibility="collapsed",
    )
    st.divider()
    st.markdown("### Your preferences")
    language = st.selectbox("Chat language", ["Bahasa Indonesia", "English", "Casual Indo-English"])
    tone = st.selectbox("Hera's personality", ["Casual & friendly", "Detailed & analytical", "Short & straightforward"])
    temperature = st.slider("AI creativity", min_value=0.0, max_value=1.0, value=0.65, step=0.05)
    st.caption("Temperature controls how creative Hera's responses may be.")
    st.divider()
    st.markdown("### Groq API")
    sidebar_key = st.text_input("API key (optional)", type="password", help="Use this for the current app session only. Prefer Streamlit Secrets for deployment.")
    st.caption("Your key is not displayed in the chat. Never share it publicly.")
    if st.button("Clear chat history", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

api_key = get_api_key(sidebar_key)

# ---------- Helpers ----------
def add_to_watchlist(title):
    if title not in st.session_state.watchlist:
        st.session_state.watchlist.append(title)
        st.session_state.watch_status[title] = "Want to Watch"

def render_movie_card(row, key_suffix=""):
    with st.container(border=True):
        st.markdown(f'<div class="movie-emoji">{row["emoji"]}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="movie-title">{row["title"]}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="movie-meta">{row["country"]} · {row["year"]} · {row["type"]}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="movie-desc">{row["synopsis"]}</div>', unsafe_allow_html=True)
        st.caption(f"Genres: {row['genres']}")
        if row["content_warning"]:
            st.caption(f"Content note: {row['content_warning']}")
        if row["title"] in st.session_state.watchlist:
            st.button("♡ Added to watchlist", key=f"added_{key_suffix}_{row['title']}", disabled=True, use_container_width=True)
        else:
            if st.button("＋ Add to watchlist", key=f"add_{key_suffix}_{row['title']}", use_container_width=True):
                add_to_watchlist(row["title"])
                st.toast(f"{row['title']} added to your watchlist ♡")
                st.rerun()

# ---------- Header ----------
st.markdown("""
<div class="hero">
  <div class="hero-kicker">A little space for your next favorite story</div>
  <div class="hero-title">HerWatchlist ♡</div>
  <div class="hero-copy">Discover K-dramas, C-dramas, and Western movies curated around your mood.
  Honest-feeling recommendations, cozy watchlists, and spoiler-conscious conversations with Hera.</div>
  <div style="margin-top:14px">
    <span class="pill">♡ Personal recommendations</span>
    <span class="pill">✦ Spoiler-conscious</span>
    <span class="pill">⌕ Cross-country entertainment</span>
  </div>
</div>
""", unsafe_allow_html=True)

# ---------- Pages ----------
if page == "Discover":
    st.subheader("What are we in the mood for?")
    mood = st.selectbox(
        "Choose your current mood",
        ["Just browsing", "I need comfort", "Something romantic", "I want to laugh",
         "A little mystery", "Something exciting", "A coming-of-age story"],
        label_visibility="collapsed",
    )
    if mood != "Just browsing":
        picks = mood_suggestions(catalog, mood)
        st.markdown(f"**A few picks for: _{mood}_**")
        if not picks.empty:
            cols = st.columns(min(3, len(picks)))
            for i, (_, row) in enumerate(picks.head(3).iterrows()):
                with cols[i % len(cols)]:
                    render_movie_card(row, f"mood_{i}")
        else:
            st.info("No exact match in the starter catalog yet. Ask Hera for help!")

    st.divider()
    c1, c2 = st.columns([2, 1])
    with c1:
        st.subheader("Explore the collection")
    with c2:
        category = st.selectbox("Content type", ["All", "K-Drama", "C-Drama", "Western Movie"], label_visibility="collapsed")
    search = st.text_input("Search by title, genre, or country", placeholder="Try romance, mystery, Korea...")
    shown = filter_catalog(catalog, category, search)
    if shown.empty:
        st.info("No titles found. Try another search.")
    else:
        cols = st.columns(3)
        for i, (_, row) in enumerate(shown.iterrows()):
            with cols[i % 3]:
                render_movie_card(row, f"discover_{i}")

elif page == "Ask Hera AI":
    st.subheader("Talk to Hera")
    st.write("Tell Hera your mood, favorite genres, or what you want to avoid. She'll help you find your next watch.")
    st.info("Hera is designed for entertainment recommendations. She avoids intentional spoilers and focuses on titles in the starter catalog when possible.")
    if not api_key:
        st.warning("Add your Groq API key in the sidebar, or configure GROQ_API_KEY in your environment / Streamlit Secrets to start chatting.")
    for message in st.session_state.messages:
        with st.chat_message(message["role"], avatar="♡" if message["role"] == "assistant" else None):
            st.markdown(message["content"])

    prompt = st.chat_input("e.g. I'm tired and want a comforting romance...", max_chars=1200)
    if prompt:
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant", avatar="♡"):
            if not api_key:
                answer = "I’d love to help! Please add your Groq API key in the sidebar first. ♡"
                st.markdown(answer)
            else:
                with st.spinner("Hera is finding your next story..."):
                    try:
                        messages = build_messages(
                            st.session_state.messages,
                            catalog,
                            language=language,
                            tone=tone,
                        )
                        answer = ask_hera(api_key, messages, temperature=temperature)
                        st.markdown(answer)
                    except requests.exceptions.Timeout:
                        answer = "The connection took too long. Please try again in a moment. ♡"
                        st.warning(answer)
                    except requests.exceptions.RequestException:
                        answer = "I can't reach the recommendation service right now. Please check your internet connection and API key, then try again."
                        st.error(answer)
                    except Exception:
                        answer = "Something unexpected happened. Please try again. If the issue continues, ask your project developer to check the app logs."
                        st.error(answer)
        st.session_state.messages.append({"role": "assistant", "content": answer})

elif page == "My Watchlist":
    st.subheader("My Watchlist ♡")
    st.write("A little collection of stories you want to spend time with.")
    if not st.session_state.watchlist:
        st.info("Your watchlist is still empty. Visit Discover and add a title you like.")
    else:
        for title in list(st.session_state.watchlist):
            match = catalog[catalog["title"] == title]
            row = match.iloc[0] if not match.empty else None
            with st.container(border=True):
                left, middle, right = st.columns([2, 2, 1])
                with left:
                    st.markdown(f"**{title}**")
                    if row is not None:
                        st.caption(f"{row['country']} · {row['year']} · {row['genres']}")
                with middle:
                    current = st.session_state.watch_status.get(title, "Want to Watch")
                    new_status = st.selectbox(
                        "Status", ["Want to Watch", "Currently Watching", "Completed"],
                        index=["Want to Watch", "Currently Watching", "Completed"].index(current),
                        key=f"status_{title}",
                    )
                    st.session_state.watch_status[title] = new_status
                with right:
                    st.write("")
                    if st.button("Remove", key=f"remove_{title}"):
                        st.session_state.watchlist.remove(title)
                        st.session_state.watch_status.pop(title, None)
                        st.rerun()
    st.caption("Prototype note: this starter version stores your watchlist in the current Streamlit session. It resets when the session is cleared.")

elif page == "About":
    st.subheader("A watchlist that feels like yours.")
    st.write("""
    **HerWatchlist** is a student startup prototype for discovering Korean dramas,
    Chinese dramas, and Western movies in one place. Instead of endlessly scrolling,
    users can explore a small curated catalog or ask Hera, the entertainment-focused AI
    assistant, for mood-based suggestions.
    """)
    st.markdown("**Our principles**")
    st.markdown("""
    - No links to pirated streaming services.
    - Spoiler-conscious summaries and clear warnings when spoiler discussion is requested.
    - Honest, balanced descriptions rather than misleading paid promotion.
    - Source-aware catalog information; the starter catalog is manually curated for demonstration.
    """)
    st.markdown("**Built with**")
    st.write("Python · Streamlit · Groq API · Llama")
    st.caption("HerWatchlist is an independent student project and is not affiliated with any film or streaming studio.")
