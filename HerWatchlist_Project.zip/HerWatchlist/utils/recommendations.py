def filter_catalog(catalog, category="All", search=""):
    result = catalog.copy()
    if category != "All":
        result = result[result["type"] == category]
    if search.strip():
        term = search.strip().lower()
        searchable = (
            result["title"].astype(str) + " " +
            result["country"].astype(str) + " " +
            result["genres"].astype(str) + " " +
            result["synopsis"].astype(str)
        ).str.lower()
        result = result[searchable.str.contains(term, na=False)]
    return result.reset_index(drop=True)

def mood_suggestions(catalog, mood):
    mapping = {
        "I need comfort": ["Comfort", "Heartwarming", "Feel-good", "Romance"],
        "Something romantic": ["Romance"],
        "I want to laugh": ["Comedy", "Romance", "Feel-good"],
        "A little mystery": ["Mystery", "Thriller"],
        "Something exciting": ["Thriller", "Mystery", "Adventure"],
        "A coming-of-age story": ["Coming of Age", "Youth", "Drama"],
    }
    terms = mapping.get(mood, [])
    if not terms:
        return catalog.head(3)
    genres = catalog["genres"].astype(str).str.lower()
    mask = genres.apply(lambda value: any(term.lower() in value for term in terms))
    result = catalog[mask]
    return result.head(3) if not result.empty else catalog.head(3)
